/**
 * 
 */
/**
 * 
 */
module Elevate_Lab_Task_7 {
	requires jdk.jdi;
	requires java.sql;
	requires java.desktop;
}