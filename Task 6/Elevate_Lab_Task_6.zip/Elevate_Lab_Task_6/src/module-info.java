/**
 * 
 */
/**
 * 
 */
module Elevate_Lab_Task_6 {
	requires java.desktop;
}